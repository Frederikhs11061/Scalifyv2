import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader: false, // fjern X-Powered-By header af sikkerhed
};

export default nextConfig;
